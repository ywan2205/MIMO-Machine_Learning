%% 
%%% =========== correlated (at receiver and transmitter side) and uncorrelated channel, signal detection compare =======

clc
clear 
close all
%
Nt = 32;             % transmit antennas
Nr = 256;             % receive  antennas
N = 10;              % Length of each frame
L = 8000;            % simulation times
EbNo = 0 : 5 : 30;   % SNRdB
%
M = 16;              % 16QAM
x = randi([0, M-1], Nt, N*L);    % original signal
s = qammod(x, M).*exp(1i*pi/4);  % modulated signal
I = eye(Nt);
%
rt = 0.8*exp(-1i*0.9349*pi);     % correlation coefficient
rr = 0.8*exp(-1i*0.9289*pi);
%
Rt = zeros(Nt, Nt);           % correlated channel at the transmitter side
for ii = 1:Nt
    for jj = 1:Nt
        if (ii==jj)
            Rt(ii,jj) = 1;
        elseif (ii<jj)
            Rt(ii,jj)=power(rt, jj-ii);
        elseif (ii>jj)
            Rt(ii,jj)=conj(Rt(jj, ii));
        end
    end
end
%
Rr = zeros(Nr, Nr);           % correlated channel at the receiver side
for ii = 1:Nr
    for jj = 1:Nr
        if (ii==jj)
            Rr(ii, jj) = 1;
        elseif (ii<jj)
            Rr(ii,jj)=power(rr, jj-ii);
        elseif (ii>jj)
            Rr(ii,jj)=conj(Rr(jj,ii));
        end
    end
end
%
for indx = 1 : length(EbNo)
    indx
    x1 = [];
    x2 = [];
    x3 = [];
    x4 = [];
    
    for indx1 = 1 : L
        indx1
        y1 = [];
        y2 = [];
        y3 = [];
        y4 = [];
        
        sigmal_1 = Nt * 1 / (10.^(EbNo(indx)/10));  % Gaussian white noise standard deviation  
        sig = 1 / (10.^(EbNo(indx)/10));
                
%========================================================================        
%%  uncorrelated channel, method1        
%========================================================================
        n = sigmal_1 * ( randn(Nr, N) + 1i*randn(Nr, N) );  % Gaussian white noise
        H = ( randn(Nr, Nt) + 1i*randn(Nr, Nt) ) / sqrt(2); % Rayleigh fading channel
        y = H * s(:, N*(indx1 - 1)+1: (N*indx1)) + n;       % received signal
        
% == mmse signal detection
        x_e1 = ( inv(H'*H + sig*I) ) * H' * y;
        y1 = x_e1;
        temp1 = qamdemod(y1.*exp(-1i*pi/4), M);
        x1 = [x1 temp1];
        
% == zf signal detection
        x_e2 = ( inv(H'*H) ) * H' * y;
        y2 = x_e2;
        temp2 = qamdemod(y2.*exp(-1i*pi/4), M);
        x2 = [x2 temp2]; 
        
% ========================================================================        
%%  correlated H,two sides method2        
% ========================================================================           
        cor_H = sqrtm(Rr) * H * ( sqrtm(Rt) )';
        cor_y = cor_H * s(:, N*(indx1 - 1)+1: (N*indx1)) + n;
        
% == mmse signal detection
        x_e3 = ( inv(cor_H' * cor_H + sig*I) ) * cor_H' * cor_y;
        y3 = x_e3;
        temp3 = qamdemod(y3.*exp(-1i*pi/4), M);
        x3 = [x3 temp3];
        
% == zf signal detection
        x_e4 = ( inv(cor_H' * cor_H) ) * cor_H' * cor_y;
        y4 = x_e4;
        temp4 = qamdemod(y4.*exp(-1i*pi/4), M);
        x4 = [x4 temp4]; 
                
    end
%  ====================== uncorrelated =======
    [tn1,bera1(indx)] = biterr(x,x1,log2(M)); %mmse 
    [tn2,bera2(indx)] = biterr(x,x2,log2(M)); %zf 
     
%  ============= correlated (at receiver and transmitter side) ==============
    [tn3,bera3(indx)] = biterr(x,x3,log2(M)); %mmse  
    [tn4,bera4(indx)] = biterr(x,x4,log2(M)); %zf
         
end
%%
% ===== uncorrelated method1
semilogy(EbNo,bera1,'-.or','LineWidth',1) %mmse 
hold on
semilogy(EbNo,bera2,'-.dk','LineWidth',1) %zf  
hold on
% ====== correlated (at receiver and transmitter side) method2
semilogy(EbNo,bera3,'-.^c','LineWidth',1) %%mmse 
hold on
semilogy(EbNo,bera4,'-.*b','LineWidth',1) %zf 
hold on
%%
axis([0 30 1e-5 1e0])
title('16QAM, uncorrelated-and-correlated-two-sides-compare')
legend('MMSE-uncorrelated', 'zf-uncorrelated', 'MMSE-correlated', 'zf-correlated')
xlabel('SNR(dB)')
ylabel('BER')
hold on
grid on
grid off







