These codes are considering integrate CNN into massive MIMO channel estimation.
we compare the BER performance of signal detection under correlated and uncorrelated channel in the same method(such as MMSE and ZF)
you can use training_and_test_data_set.m file to produce traing and test data 